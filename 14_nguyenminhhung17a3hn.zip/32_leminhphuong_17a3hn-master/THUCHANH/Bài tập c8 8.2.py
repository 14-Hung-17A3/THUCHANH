x=int(input("Nhập vào giá trị của x :"))
if x<0:
    print("Giá trị tuyệt đối của x là :",-1*x)
else :
    print("Giá trị tuyệt đối của x là :",x) 