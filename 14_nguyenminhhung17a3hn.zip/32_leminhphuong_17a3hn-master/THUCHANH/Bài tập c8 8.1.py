a,b,c,d=map(int,input("Nhập vào 4 số tư nhiên bất kỳ :"))
print("Số lớn nhất trong 4 chữ số là :",max(a,b,c,d))
print("Số nhỏ nhất trong 4 chữ số là :",min (a,b,c,d))
