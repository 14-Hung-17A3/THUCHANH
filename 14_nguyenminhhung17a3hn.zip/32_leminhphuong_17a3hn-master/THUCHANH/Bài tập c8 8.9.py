n=int(input("Nhập vào giá trị của n"))
while 1<=n:
    print(n)
    n-=1
else:
    print("start!!")