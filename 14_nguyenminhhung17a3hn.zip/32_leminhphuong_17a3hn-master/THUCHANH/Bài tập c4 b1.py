#1
a = float(input("Nhập số cần tính bình phương: "))
if a > 0:
    b =a**2
    print(f"Bình phương của {a} là {b}")
else:
    print("Số bạn nhập không phải số dương.")