a=int(input("Nhập số nguyên thứ 1 là:"))
b=int(input("Nhập số nguyên thứ 2 là :"))
c=int(input("Nhập số nguên thứ 3 là :"))
S=a+b+c
print("Tổng của 3 số nguyên là :",S)