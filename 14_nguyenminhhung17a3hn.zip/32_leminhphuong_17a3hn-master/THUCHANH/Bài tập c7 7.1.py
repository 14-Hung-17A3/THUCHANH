x=int(input("nhap x :"))
s=(1+x)+(x**3/3)+(x**5/5)
print(s)