#Câu2
x=10
y=5
tong=x+y
hieu=x-y
tich=x*y
thuong=x/y
print("tong cua hai so ", x,"+",y,"=",tong)
print("hieu cua hai so ",x,"-",y,"=",hieu)
print("tich cua hai so ",x,"*",y,"=",tich)
print("thuong cua hai so",x,"/",y,"=",thuong)