x=int(input("Nhập vào giá trị của x :"))
if (x%1==0 and x%x==0):
    print("Số đó là số nguyên")
else :
    print("Số đó không phải là số nguyên ")