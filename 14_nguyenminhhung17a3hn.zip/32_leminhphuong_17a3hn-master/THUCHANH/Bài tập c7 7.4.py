x=10
y=4
print('x=%d,y=%d'%(x,y))
equivelence= x==y
print('x==y is',equivelence)
equivelence= x!=y
print('x!=y is',equivelence)
equivelence= x>y
print('x>y is',equivelence)

x=8
x=9
print('x=%d,y=%d'%(x,y))
equivelence= x>=y
print('x>=y is',equivelence)
equivelence=  x<y
print('x<y is',equivelence)
equivelence= x<=y
print('x<=y is',equivelence)