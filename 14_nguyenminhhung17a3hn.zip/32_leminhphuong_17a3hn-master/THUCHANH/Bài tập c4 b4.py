#4
number1 = float(input("Nhập số thứ nhất:"))
number2 = float(input("Nhập số thứ hai:"))
number3 = float(input("Nhập số thứ ba:"))
max_number = max(number1, number2, number3)
print("Số lớn nhất trong ba số là:", max_number)