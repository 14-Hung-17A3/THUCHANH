n=int(input("Nhập vào giá trị của n :"))
x=int(input("Nhập vào giá trị của x :"))
S=(x*x+1)**n
print("Giá trị của s là :",S)