print("Phương trình bậc nhất dạng : ax+b=0")
a=int(input("Nhập vào giá trị của a :"))
b=int(input("Nhập vào giá trị của b :"))
if a != 0:
    print("Với a khác 0 pt có nghiệm x=-b/a")
    x=-b/a
    print("Nghiệm của phương trình là :",x)
else:
    print("Phương trình vô nghiệm ") 