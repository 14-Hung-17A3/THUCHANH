#câu5
so_luong=int(input("Nhập số lượng :"))
don_gia=int(input("Nhập đơn giá :"))
print("Thành tiền =",so_luong,"*",don_gia,"=",so_luong*don_gia)